package com.example.lotus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.rememberCameraPositionState

class MainActivity : ComponentActivity() {
    private lateinit var geofencingClient: GeofencingClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MapScreen()
        }
        geofencingClient = LocationServices.getGeofencingClient(this)
    }

    @Composable
    fun MapScreen() {
        val cameraPositionState = rememberCameraPositionState {
            position = CameraPosition.fromLatLngZoom(LatLng(x_iiitd, y_iiitd), 15f)
        }
        GoogleMap(cameraPositionState = cameraPositionState)
    }
}


fun setupGeofence() {
    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        // TODO: Request location permissions
        return
    }

    val geofence = Geofence.Builder()
        .setRequestId("LotusTemple")
        .setCircularRegion(
            x_lotus, y_lotus,
            100f
        )
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
        .build()

    val geofencingRequest = GeofencingRequest.Builder()
        .addGeofence(geofence)
        .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
        .build()

    val geofencePendingIntent: PendingIntent = getGeofencePendingIntent()

    geofencingClient.addGeofences(geofencingRequest, geofencePendingIntent).addOnSuccessListener {
    }.addOnFailureListener {
    }
}

private fun getGeofencePendingIntent(): PendingIntent {
    val intent = Intent(this, GeofenceBroadcastReceiver::class.java)
    return PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
}