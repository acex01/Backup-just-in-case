package com.example.nativeexamplecompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.lang.reflect.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MatrixProductScreen()
        }
    }
}

@Composable
fun MatrixProductScreen() {
    val viewModel: MatrixViewModel = viewModel()
    Column() {
        Text("Product of Matrices:")
        viewModel.result.forEach { row ->
            Text(row.joinToString(" ") { it.toString() })
        }
    }
}