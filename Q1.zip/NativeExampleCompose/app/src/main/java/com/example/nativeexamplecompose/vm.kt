package com.example.nativeexamplecompose

import androidx.lifecycle.ViewModel

class MatrixViewModel : ViewModel() {
    private val N = 3
    private val A = arrayOf(
        arrayOf(1, 2, 3),
        arrayOf(4, 5, 6),
        arrayOf(7, 8, 9)
    )
    private val B = arrayOf(
        arrayOf(9, 8, 7),
        arrayOf(6, 5, 4),
        arrayOf(3, 2, 1)
    )
    val result = Array(N) { IntArray(N) }

    init {
        multiplyMatrices()
    }

    private fun multiplyMatrices() {
        for (i in 0 until N) {
            for (j in 0 until N) {
                result[i][j] = 0
                for (k in 0 until N) {
                    result[i][j] += A[i][k] * B[k][j]
                }
            }
        }
    }
}